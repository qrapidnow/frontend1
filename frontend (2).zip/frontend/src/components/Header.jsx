import React from 'react';
import './Header.css';

const Header = ({ restaurantName }) => {
  return (
    <header className="header">
      <h1 className="header-title">{restaurantName || "RESTAURANT'S NAME"}</h1>
      <img src="/src/assets/restaurant-image.jpg" alt="Restaurant" className="restaurant-image" />
    </header>
  );
};

export default Header;
