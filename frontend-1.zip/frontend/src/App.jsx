import React, { useState } from 'react';
import './App.css';
import Header from './components/Header';
import SearchBar from './components/SearchBar';
import CategoryButtons from './components/CategoryButtons';
import Navbar from './components/NavBar';
import Menu from './components/Menu';
import Cart from './components/Cart';
import CartItem from './components/CartItem';

const App = () => {
  const [cart, setCart] = useState([]);
  const [showCart, setShowCart] = useState(false);
  const [showCartItem, setShowCartItem] = useState(false);
  const [foodItemCounts, setFoodItemCounts] = useState({});

  const addItem = (item) => {
    const updatedCart = [...cart, item];
    setCart(updatedCart);
    updateItemCount(item.id, 1);
  };

  const getTotalItems = () => {
    return cart.length;
  };

  const handleViewOrderClick = () => {
    setShowCartItem(true);
  };

  const handleCartClick = () => {
    setShowCart(!showCart);
    setShowCartItem(false);
  };

  const handleCartItemToggle = () => {
    setShowCartItem(!showCartItem);
    setShowCart(false);
  };

  const removeItem = (itemToRemove) => {
    const updatedCart = cart.filter((item) => item !== itemToRemove);
    setCart(updatedCart);
    updateItemCount(itemToRemove.id, -itemToRemove.quantity);
  };

  const updateItemCount = (itemId, countChange) => {
    const currentCount = foodItemCounts[itemId] || 0;
    const newCount = Math.max(0, currentCount + countChange);
    setFoodItemCounts({ ...foodItemCounts, [itemId]: newCount });
  };

  return (
    <div className="app">
      <Header />
      <SearchBar />
      <div className="content-container">
        <CategoryButtons handleCartItemToggle={handleCartItemToggle} />
        <Navbar handleCartClick={handleCartClick} />
      </div>
      <Menu addItem={addItem} updateItemCount={updateItemCount} />
      {getTotalItems() > 0 && (
        <div className="view-order-bar" onClick={handleViewOrderClick}>
          <span>View Order</span>
          <span className="order-count">{getTotalItems()}</span>
        </div>
      )}
      {showCart && !showCartItem && <Cart cartItems={cart} setShowCart={setShowCart} />}
      {showCartItem && (
        <div className="cart-item-container">
          <CartItem
            cartItems={cart}
            setCart={setCart}
            removeItem={removeItem}
            setShowCartItem={setShowCartItem}
            updateItemCount={updateItemCount}
          />
        </div>
      )}
    </div>
  );
};

export default App;
