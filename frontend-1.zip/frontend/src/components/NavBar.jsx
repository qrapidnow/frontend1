import React from 'react';
import './Navbar.css';

const Navbar = () => {
  const handleScrollToSection = (id) => {
    document.getElementById(id).scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <nav className="navbar">
      <button onClick={() => handleScrollToSection('breakfast')}>Breakfast</button>
      <button onClick={() => handleScrollToSection('appetizers')}>Appetizers</button>
      <button onClick={() => handleScrollToSection('mains')}>Mains</button>
      <button onClick={() => handleScrollToSection('desserts')}>Desserts</button>
    </nav>
  );
};

export default Navbar;
