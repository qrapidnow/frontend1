import React from 'react';
import './Menu.css';
import FoodItemCard from './FoodItemCard';

const Menu = ({ addItem, updateItemCount }) => {
  const sections = [
    {
      title: 'BREAKFAST',
      items: [
        { id: 1, name: 'Omelette', price: 50, description: 'An egg dish...', image: '/src/assets/omelette.jpg', weight: '200g' },
        { id: 2, name: 'French Toast', price: 50, description: 'A dish made of bread...', image: '/src/assets/french-toast.jpeg', weight: '200g' },
        // Additional items...
      ]
    },
    {
      title: 'APPETIZERS',
      items: [
        { id: 1, name: 'Omelette', price: 50, description: 'An egg dish...', image: '/src/assets/omelette.jpg', weight: '200g' },
        { id: 2, name: 'French Toast', price: 50, description: 'A dish made of bread...', image: '/src/assets/french-toast.jpeg', weight: '200g' },
        // Additional items...
      ]
    },
    {
      title: 'MAINS',
      items: [
        { id: 1, name: 'Omelette', price: 50, description: 'An egg dish...', image: '/src/assets/omelette.jpg', weight: '200g' },
        { id: 2, name: 'French Toast', price: 50, description: 'A dish made of bread...', image: '/src/assets/french-toast.jpeg', weight: '200g' },
        // Additional items...
      ]
    },
    {
      title: 'DESSERTS',
      items: [
        { id: 1, name: 'Omelette', price: 50, description: 'An egg dish...', image: '/src/assets/omelette.jpg', weight: '200g' },
        { id: 2, name: 'French Toast', price: 50, description: 'A dish made of bread...', image: '/src/assets/french-toast.jpeg', weight: '200g' },
        // Additional items...
      ]
    },
  ];

  return (
    <div className="menu">
      {sections.map(section => (
        <div key={section.title} className="menu-section">
          <h2>{section.title}</h2>
          <div className="menu-items-container">
            <div className="menu-items">
              {section.items.map(item => (
                <FoodItemCard key={item.id} item={item} addItem={addItem} updateItemCount={updateItemCount} />
              ))}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default Menu;
