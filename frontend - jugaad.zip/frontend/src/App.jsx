import React, { useEffect, useState } from 'react';
import './App.css';
import Header from './components/Header';
import SearchBar from './components/SearchBar';
import Navbar from './components/NavBar'; // Ensure this is imported
import Menu from './components/Menu';
import Cart from './components/Cart';
import CartItem from './components/CartItem';
import axios from 'axios';

const App = () => {
  const [cart, setCart] = useState([]);
  const [showCart, setShowCart] = useState(false);
  const [showCartItem, setShowCartItem] = useState(false);
  const [foodItemCounts, setFoodItemCounts] = useState({});
  const [restaurantName, setRestaurantName] = useState('');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userId, setUserId] = useState('');

  useEffect(() => {
    const fetchUsersAndToken = async () => {
      try {
        console.log('Fetching list of users');
        const usersResponse = await axios.get('http://localhost:3001/users');
        const users = usersResponse.data;
        if (users.length > 0) {
          const firstUserId = users[0]._id; // Using the first user for demonstration; can be dynamic
          setUserId(firstUserId);
          console.log(`Fetched user ID: ${firstUserId}`);
          const tokenResponse = await axios.get(`http://localhost:3001/token/${firstUserId}`);
          const token = tokenResponse.data.token;
          console.log('Fetched Token:', token);
          if (token) {
            localStorage.setItem('token', token);
            const restaurantResponse = await fetchRestaurant(token);
            localStorage.setItem('restaurantId', restaurantResponse.data._id); // Store restaurant ID in localStorage
          } else {
            console.error('No token found for user');
          }
        } else {
          console.error('No users found');
        }
      } catch (error) {
        console.error('Error fetching users or token:', error);
      }
    };

    fetchUsersAndToken();
  }, []);

  const fetchRestaurant = async (token) => {
    console.log('Using Token:', token);
    try {
      const response = await axios.get('http://localhost:3001/restaurants', {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      if (response.data && response.data.name) {
        console.log('Fetched Restaurant Data:', response.data);
        setRestaurantName(response.data.name);
        setIsLoggedIn(true);
        return response.data;
      } else {
        console.error('No restaurant data found');
      }
    } catch (error) {
      console.error('Error fetching restaurant data:', error);
    }
  };

  const addItem = (item) => {
    const updatedCart = [...cart, item];
    setCart(updatedCart);
    updateItemCount(item.id, 1);
  };

  const getTotalItems = () => {
    return cart.length;
  };

  const handleViewOrderClick = () => {
    setShowCartItem(true);
  };

  const handleCartClick = () => {
    setShowCart(!showCart);
    setShowCartItem(false);
  };

  const handleCartItemToggle = () => {
    setShowCartItem(!showCartItem);
    setShowCart(false);
  };

  const removeItem = (itemToRemove) => {
    const updatedCart = cart.filter((item) => item !== itemToRemove);
    setCart(updatedCart);
    updateItemCount(itemToRemove.id, -itemToRemove.quantity);
  };

  const updateItemCount = (itemId, countChange) => {
    const currentCount = foodItemCounts[itemId] || 0;
    const newCount = Math.max(0, currentCount + countChange);
    setFoodItemCounts({ ...foodItemCounts, [itemId]: newCount });
  };

  if (!isLoggedIn) {
    return <div>Loading...</div>;
  }

  return (
    <div className="app">
      <Header restaurantName={restaurantName} />
      <SearchBar />
      <Navbar />
      <div className="content-container">
        <Menu addItem={addItem} updateItemCount={updateItemCount} />
      </div>
      {getTotalItems() > 0 && (
        <div className="view-order-bar" onClick={handleViewOrderClick}>
          <span>View Order</span>
          <span className="order-count">{getTotalItems()}</span>
        </div>
      )}
      {showCart && !showCartItem && <Cart cartItems={cart} setShowCart={setShowCart} />}
      {showCartItem && (
        <div className="cart-item-container">
          <CartItem
            cartItems={cart}
            setCart={setCart}
            removeItem={removeItem}
            setShowCartItem={setShowCartItem}
            updateItemCount={updateItemCount}
          />
        </div>
      )}
    </div>
  );
};

export default App;
